#!/usr/bin/env python2
# -*- coding: utf-8 -*-

"""
@author : Hao Zhang, Dandan Guo, Bo Chen, and Mingyuan Zhou 
@Email : zhanghao_xidian@163.com      gdd_xidian@126.com    bchen@mail.xidian.edu.cn  mingyuan.zhou@mccombs.utexas.edu

Description:
    The module function realizing some sampling in WHAI

Citation: 
    WHAI: Weibull Hybrid Autoencoding Inference for Deep Topic Modeling
    Hao Zhang, Bo Chen, Dandan Guo, and Mingyuan Zhou
    ICLR 2018

Contact:
    Hao Zhang
    zhanghao_xidian@163.com
    Xidian University, Xi'an, China
       
    Bo Chen
    bchen@mail.xidian.edu.cn
    Xidian University, Xi'an, China
   
LICENSE
=======================================================================
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
Copyright (c), 2018, Hao Zhang 
zhanghao_xidian@163.com
       
"""

import numpy as np
import numpy.ctypeslib as npct
import ctypes  
from ctypes import *


array_2d_double = npct.ndpointer(dtype=np.double,ndim=2,flags='C')
array_1d_double = npct.ndpointer(dtype=np.double,ndim=1,flags='C')
array_int = npct.ndpointer(dtype=np.int32,ndim=0,flags='C')
ll = ctypes.cdll.LoadLibrary   

Multi_lib = ll("./libMulti_Sample.so")
Multi_lib.Multi_Sample.restype = None
Multi_lib.Multi_Sample.argtypes = [array_2d_double,array_2d_double,array_2d_double,array_2d_double,array_2d_double, c_int, c_int, c_int]

Crt_Multi_lib = ll("./libCrt_Multi_Sample.so")
Crt_Multi_lib.Crt_Multi_Sample.restype = None
Crt_Multi_lib.Crt_Multi_Sample.argtypes = [array_2d_double,array_2d_double,array_2d_double,array_2d_double,array_2d_double, c_int, c_int, c_int]

realmin = 2.2e-308
# check correct
def Calculate_pj(c_j,T):  #c_j 0-T    
    p_j = []
    N = c_j[1].size
    p_j.append((1-np.exp(-1))*np.ones([1,N]))     # test same as Matlab exp(-1)
    p_j.append(1/(1+c_j[1]))
    
    for t in [i for i in range(T+1) if i>1]:    # only T>=2 works
        tmp = -np.log(np.maximum(1-p_j[t-1],realmin));
        p_j.append(tmp/(tmp+c_j[t]))
        
    return p_j
        
def Multrnd_Matrix(X_t,Phi_t,Theta_t):
    V = X_t.shape[0]
    J = X_t.shape[1]
    K = Theta_t.shape[0]
    Xt_to_t1_t = np.zeros([K,J], order = 'C').astype('double')
    WSZS_t = np.zeros([V,K], order = 'C').astype('double')
    
    Multi_lib.Multi_Sample(X_t,Phi_t,Theta_t, WSZS_t, Xt_to_t1_t, V,K,J)
#    V = X_t.shape[0]
#    J = X_t.shape[1]
#    K = Theta_t.shape[0]
#    a = Sampler() 
#    Xt_to_t1_t = np.zeros([K,J])
#    WSZS_t = np.zeros([V,K])
#    Embedding = np.zeros(K,dtype='uint32')
#    Augment_Matrix = np.zeros([V,K,J],dtype='uint32')
#    
#    for n in range(Xt_xy.shape[1]):
#        v = Xt_xy[0,n]
#        j = Xt_xy[1,n]
#        Pro =  (Phi_t[v,:] *Theta_t[:,j])/(Phi_t[v,:] *Theta_t[:,j]).sum(0)
#        a.multinomial(X_t[v,j],Pro,Embedding)   ## output to embedding
#        Augment_Matrix[v,:,j] = Embedding
#    Xt_to_t1_t[:,:] = Augment_Matrix.sum(0);
#    WSZS_t[:,:] = Augment_Matrix.sum(2);


    return Xt_to_t1_t, WSZS_t     
    
def Crt_Multirnd_Matrix(Xt_to_t1_t,Phi_t1,Theta_t1):
    Kt = Xt_to_t1_t.shape[0]
    J = Xt_to_t1_t.shape[1]
    Kt1 = Theta_t1.shape[0]
    Xt_to_t1_t1 = np.zeros([Kt1,J],order = 'C').astype('double')
    WSZS_t1 = np.zeros([Kt,Kt1],order = 'C').astype('double')
    
    Crt_Multi_lib.Crt_Multi_Sample(Xt_to_t1_t, Phi_t1,Theta_t1, WSZS_t1, Xt_to_t1_t1, Kt, Kt1 , J)
    
    
#    Kt = Xt_to_t1_t.shape[0]
#    J = Xt_to_t1_t.shape[1]
#    Kt1 = Theta_t1.shape[0]
#    Xt1 = np.zeros([Kt,J])
#    a = Sampler()
#    Xt_to_t1_t1 = np.zeros([Kt1,J])
#    WSZS_t1 = np.zeros([Kt,Kt1])
#    Embedding = np.zeros(Kt1,dtype='uint32')
#    Augment_Matrix = np.zeros([Kt,Kt1,J],dtype='uint32')
#    for k in range(Kt):
#        for j in range(J):
#            if Xt_to_t1_t[k,j] < 0.5:
#                continue
#            else:
#                Xt1[k,j] = a.crt(Xt_to_t1_t[k,j], np.dot(Phi_t1[k,:],Theta_t1[:,j]))
#                Pro = Phi_t1[k,:]*Theta_t1[:,j] / (Phi_t1[k,:]*Theta_t1[:,j]).sum(0)
#                a.multinomial(Xt1[k,j],Pro,Embedding)
#                Augment_Matrix[k,:,j] = Embedding
#    Xt_to_t1_t1[:,:] = Augment_Matrix.sum(0)
#    WSZS_t1[:,:] = Augment_Matrix.sum(2)
    return Xt_to_t1_t1 , WSZS_t1
    
def Sample_Phi(WSZS_t,Eta_t):   # (array, scalar)
    Kt = WSZS_t.shape[0]
    Kt1 = WSZS_t.shape[1]
    Phi_t_shape = WSZS_t + Eta_t
    Phi_t = np.zeros([Kt,Kt1])
    Phi_t = np.random.gamma(Phi_t_shape,1)
    
    temp=np.sum(Phi_t,axis=0)

    tempdex = np.nonzero(temp)[0]  
    Phi_t[:,tempdex] = Phi_t[:,tempdex] / temp[tempdex]
    
    Phi_t[:,np.nonzero(temp==0)[0]]  = 0

    return Phi_t
    
def Sample_Theta(Xt_to_t1_t,c_j_t1,p_j_t,shape):
    Kt = Xt_to_t1_t.shape[0]
    N = Xt_to_t1_t.shape[1]
    Theta_t = np.zeros([Kt,N])
    Theta_t_shape = Xt_to_t1_t + shape
    Theta_t[:,:] = np.random.gamma(Theta_t_shape,1) / (c_j_t1[0,:]-np.log(np.maximum(realmin,1-p_j_t[0,:])))
#    a = Sampler()
#    for kt in range(Kt):
#        for n in range(N):
#            Theta_t[kt,n] = a.gamma(Theta_t_shape[kt,n],1)/(c_j_t1[0,n]-np.log(np.maximum(realmin,1-p_j_t[0,n])))
    return Theta_t

def ProjSimplexSpecial(Phi_tmp,Phi_old,epsilon):
    Phinew = Phi_tmp - (Phi_tmp.sum(0) - 1) * Phi_old
    if  np.where(Phinew[:,:]<=0)[0].size >0:
        Phinew = np.maximum(epsilon,Phinew)
        Phinew = Phinew/np.maximum(realmin,Phinew.sum(0))
    return Phinew

def Reconstruct_error(X,Phi,Theta):
    return np.power(X-np.dot(Phi,Theta),2).sum()
    
    