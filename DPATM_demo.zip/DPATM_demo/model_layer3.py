# -*- coding: utf-8 -*-
"""
@author : Hao Zhang, Dandan Guo, Bo Chen, and Mingyuan Zhou 
@Email : zhanghao_xidian@163.com      gdd_xidian@126.com    bchen@mail.xidian.edu.cn  mingyuan.zhou@mccombs.utexas.edu

Description:
    The module function realizing three-layer model in WHAI

Citation: 
    WHAI: Weibull Hybrid Autoencoding Inference for Deep Topic Modeling
    Hao Zhang, Bo Chen, Dandan Guo, and Mingyuan Zhou
    ICLR 2018

Contact:
    Hao Zhang
    zhanghao_xidian@163.com
    Xidian University, Xi'an, China
       
    Bo Chen
    bchen@mail.xidian.edu.cn
    Xidian University, Xi'an, China
   
LICENSE
=======================================================================
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
Copyright (c), 2018, Hao Zhang 
zhanghao_xidian@163.com
       
"""

import numpy as np
import theano as th
import theano.tensor as T
import numpy.random as rng
import PGBN_sampler


class model:
	def __init__(self, dimX, Num, Num_dic, batch_size, Sampling_Num, updataparam, method, Prior, eulergamma, Dataname, H,eta,Setting):

		self.dimX = dimX
		self.Num_dic1 = Num_dic[0]
		self.Num_dic2 = Num_dic[1]
		self.Num_dic3 = Num_dic[2]
		self.Num = Num
		self.Sampling_Num = Sampling_Num
		self.Dataname = Dataname

		self.Theta1Scale_prior = Prior[0]
		self.Theta2Scale_prior = Prior[1]
		self.Theta3Shape_prior = Prior[2]
		self.Theta3Scale_prior = Prior[3]

		self.eta = eta
		self.H1 = H[0]
		self.H2 = H[1]
		self.H3 = H[2]

		self.learning_rate_Weight = updataparam[0]
		self.beta1_Weight = updataparam[1]
		self.beta2_Weight = updataparam[2]
		self.epsilon = updataparam[3]

		self.batch_size = batch_size
		self.sigmaInit = 0.01

		self.Lowerbound = 0
		self.Likelihood = 0

		self.eulergamma = eulergamma

		self.ForgetRate = np.power((Setting['tao0FR'] + np.linspace(1,Setting['Iterall'],Setting['Iterall'])),-Setting['kappa0FR'])
		epsit = np.power((Setting['tao0'] + np.linspace(1,Setting['Iterall'],Setting['Iterall'])),-Setting['kappa0'])
		self.epsit = Setting['epsi0']*epsit/epsit[0]

		self.MBObserved = 0
		self.NDot = []


		self.Gradient  = 0    
        
   

	def initParams(self):
		realmin = 2.2e-308

		self.Phi=[]
		self.Phi.append(0.2+0.8*np.random.rand(self.dimX,self.Num_dic1))
		self.Phi.append(0.2+0.8*np.random.rand(self.Num_dic1,self.Num_dic2))
		self.Phi.append(0.2+0.8*np.random.rand(self.Num_dic2,self.Num_dic3))

		for t in range(3):
			self.Phi[t] = self.Phi[t] / np.maximum(realmin,self.Phi[t].sum(0))

		W1 = np.random.normal(0,self.sigmaInit,[self.H1,self.dimX])
		b1 = np.random.normal(0,self.sigmaInit,[self.H1,1])

		W2 = np.random.normal(0,self.sigmaInit,[1,self.H1])
		b2 = np.random.normal(0,self.sigmaInit,[1,1])

		W3 = np.random.normal(0,self.sigmaInit,[self.Num_dic1,self.H1])
		b3 = np.random.normal(0,self.sigmaInit,[self.Num_dic1,1])

		W4 = np.random.normal(0,self.sigmaInit,[self.H2,self.H1])
		b4 = np.random.normal(0,self.sigmaInit,[self.H2,1])

		W5 = np.random.normal(0,self.sigmaInit,[1,self.H2])
		b5 = np.random.normal(0,self.sigmaInit,[1,1])

		W6 = np.random.normal(0,self.sigmaInit,[self.Num_dic2,self.H2])
		b6 = np.random.normal(0,self.sigmaInit,[self.Num_dic2,1])

		W7 = np.random.normal(0,self.sigmaInit,[self.H3,self.H2])
		b7 = np.random.normal(0,self.sigmaInit,[self.H3,1])

		W8 = np.random.normal(0,self.sigmaInit,[1,self.H3])
		b8 = np.random.normal(0,self.sigmaInit,[1,1])

		W9 = np.random.normal(0,self.sigmaInit,[self.Num_dic3,self.H3])
		b9 = np.random.normal(0,self.sigmaInit,[self.Num_dic3,1])

		self.NDot = [0]*3
		self.Xt_to_t1 = [0] * 3
		self.WSZS = [0] * 3
		self.EWSZS = [0] * 3

		self.params = [W1,W2,W3,W4,W5,W6,W7,W8,W9,b1,b2,b3,b4,b5,b6,b7,b8,b9]


		self.m = [0] * len(self.params)
		self.v = [0] * len(self.params)

	def KL_GamWei(self,GamShape,GamScale,WeiShape,WeiScale):
		Out = self.eulergamma * (1-1/WeiShape) + T.log(WeiScale/WeiShape) + 1 + GamShape*T.log(GamScale) - T.gammaln(GamShape) + (GamShape-1)*(T.log(WeiScale)-self.eulergamma/WeiShape) - GamScale*WeiScale*T.gamma(1 + 1/WeiShape)

		return Out

	def createGradientFunctions(self):
		#Create the Theano variables
		Phi1,Phi2,Phi3,W1,W2,W3,W4,W5,W6,W7,W8,W9,x,Theta1_eps,Theta2_eps,Theta3_eps = T.dmatrices("Phi1","Phi2","Phi3","W1","W2","W3","W4","W5","W6","W7","W8","W9","x","Theta1_eps","Theta2_eps","Theta3_eps")
		b1,b2,b3,b4,b5,b6,b7,b8,b9 = T.dcols("b1","b2","b3","b4","b5","b6","b7","b8","b9")
		alpha = T.scalar("alpha")

		h1 = T.nnet.softplus(T.dot(W1,T.log(1+x))+b1)
		h2 = T.nnet.softplus(T.dot(W4,h1)+b4)
		h3 = T.nnet.softplus(T.dot(W7,h2)+b7)

		Theta3_shape = T.maximum(T.exp(T.dot(W8,h3)+b8),1e-8)
		Theta3_scale = T.exp(T.dot(W9,h3)+b9)
		Theta3_shape = T.repeat(Theta3_shape,self.Num_dic3,axis=0)
		Theta3 = ( Theta3_scale * ((-T.log(1-Theta3_eps)) ** (1/Theta3_shape)) )

		Theta2_shape = T.maximum(T.exp(T.dot(W5,h2)+b5),1e-8)
		Theta2_scale = T.exp(T.dot(W6,h2)+b6)
		Theta2_shape = T.repeat(Theta2_shape,self.Num_dic2,axis=0) 
		Theta2 = Theta2_scale * ((-T.log(1-Theta2_eps)) ** (1/Theta2_shape))


		Theta1_shape = T.maximum(T.exp(T.dot(W2,h1)+b2),1e-8)
		Theta1_scale = T.exp(T.dot(W3,h1)+b3)
		Theta1_shape = T.repeat(Theta1_shape,self.Num_dic1,axis=0) 
		Theta1 = Theta1_scale * ((-T.log(1-Theta1_eps)) ** (1/Theta1_shape))


		Theta3_KL = T.sum(self.KL_GamWei(self.Theta3Shape_prior, self.Theta3Scale_prior, Theta3_shape, Theta3_scale))
		Theta2_KL = T.sum(self.KL_GamWei(T.dot(Phi3,Theta3), self.Theta2Scale_prior, Theta2_shape, Theta2_scale))
		Theta1_KL = T.sum(self.KL_GamWei(T.dot(Phi2,Theta2), self.Theta1Scale_prior, Theta1_shape, Theta1_scale))


		Likelihood = T.sum(x*T.log(T.dot(Phi1,Theta1)) - T.dot(Phi1,Theta1) - T.gammaln(x+1))

		gradvariables = [W1,W2,W3,W4,W5,W6,W7,W8,W9,b1,b2,b3,b4,b5,b6,b7,b8,b9]

		Loss =  self.Num/self.batch_size*(alpha*Theta3_KL + alpha*Theta2_KL + alpha*Theta1_KL + Likelihood)

		LB = Theta3_KL + Theta2_KL + Theta1_KL + Likelihood

		derivatives = T.grad(Loss,gradvariables)
  
		derivatives.append(LB)
		derivatives.append(Likelihood)

		self.gradientfunction= th.function(gradvariables+[x,Phi1,Phi2,Phi3,Theta1_eps,Theta2_eps,Theta3_eps,alpha],  derivatives, on_unused_input='ignore')
		self.likelihoodfunc = th.function(gradvariables+[x,Phi1,Phi2,Phi3,Theta1_eps,Theta2_eps,Theta3_eps],  Likelihood , on_unused_input='ignore')
		self.thetafunc = th.function(gradvariables+[x,Phi1,Phi2,Phi3,Theta1_eps,Theta2_eps,Theta3_eps],  [Theta1,Theta2,Theta3], on_unused_input='ignore')
		self.lowerboundfunc = th.function(gradvariables + [x, Phi1, Phi2, Phi3, Theta1_eps, Theta2_eps, Theta3_eps], LB, on_unused_input='ignore')

	def iterate(self,P,data,epoch):
		"""Main method, slices data in minibatches and performs an iteration"""
		[dimX,N] = data.shape
		randperm = rng.permutation(N)
		data_tmp = np.array(data[:,randperm],order = 'C')
		batches = np.arange(0,N,self.batch_size)   
		alpha = 1

		if batches[-1] != N:
			batches = np.append(batches,N)
		MBratio = len(batches)-1        

		for MBt in range(MBratio):     
			self.MBObserved = (epoch-1)*MBratio + MBt

			miniBatch = data_tmp[:,batches[MBt]:batches[MBt+1]]

			P = self.params
			totalGradients = self.getGradients(miniBatch,P,epoch,alpha)
			self.Gradient = totalGradients
			self.updateParams(totalGradients)
			Theta = self.calculateTheta(miniBatch,self.params)
			self.updatePhi(totalGradients,MBratio,self.MBObserved,miniBatch,Theta)


	def getGradients(self,miniBatch,P,epoch,alpha):
		totalGradients = [0]*len(self.params)

		for l in range(self.Sampling_Num):
			Theta1_e = np.random.uniform(0,1,[self.Num_dic1,miniBatch.shape[1]])
			Theta2_e = np.random.uniform(0,1,[self.Num_dic2,miniBatch.shape[1]])
			Theta3_e = np.random.uniform(0,1,[self.Num_dic3,miniBatch.shape[1]])

			gradients = self.gradientfunction(*P,x=miniBatch,Phi1=self.Phi[0],Phi2=self.Phi[1],Phi3=self.Phi[2],
											  Theta1_eps=Theta1_e,Theta2_eps=Theta2_e,Theta3_eps=Theta3_e,alpha=alpha)

			for i in range(len(self.params)):
				totalGradients[i] += gradients[i]

		self.Lowerbound += gradients[-2]
		self.Likelihood += gradients[-1]

		return totalGradients


	def calculatelikelihood(self,miniBatch,Phi,P):

		for l in range(self.Sampling_Num):
			Theta1_e = np.random.uniform(0,1,[self.Num_dic1,miniBatch.shape[1]])
			Theta2_e = np.random.uniform(0,1,[self.Num_dic2,miniBatch.shape[1]])
			Theta3_e = np.random.uniform(0,1,[self.Num_dic3,miniBatch.shape[1]])

			LH = self.likelihoodfunc(*P,x=miniBatch,Phi1=Phi[0],Phi2=Phi[1],Phi3=Phi[2],
									 Theta1_eps=Theta1_e,Theta2_eps=Theta2_e,Theta3_eps=Theta3_e)

		return LH

	def calculateTheta(self,X,P):

		for l in range(self.Sampling_Num):
			Theta1_e = np.random.uniform(0,1,[self.Num_dic1,X.shape[1]])
			Theta2_e = np.random.uniform(0,1,[self.Num_dic2,X.shape[1]])
			Theta3_e = np.random.uniform(0,1,[self.Num_dic3,X.shape[1]])


			Theta= self.thetafunc(*P,x=X,Phi1=self.Phi[0],Phi2=self.Phi[1],Phi3=self.Phi[2],
								  Theta1_eps=Theta1_e,Theta2_eps=Theta2_e,Theta3_eps=Theta3_e)

		return Theta

	def updatePhi(self,totalGradients,MBratio,MBObserved,miniBatch,Theta):
		Xt = miniBatch


		for t in range(3):
			if t == 0:
				self.Xt_to_t1[t], self.WSZS[t] = PGBN_sampler.Multrnd_Matrix(Xt.astype('double'),self.Phi[t],Theta[t])
			else:
				self.Xt_to_t1[t], self.WSZS[t] = PGBN_sampler.Crt_Multirnd_Matrix(self.Xt_to_t1[t-1],self.Phi[t],Theta[t])

			self.EWSZS[t] = MBratio * self.WSZS[t]

			if (MBObserved == 0):
				self.NDot[t] = self.EWSZS[t].sum(0)
			else:
				self.NDot[t] = (1 - self.ForgetRate[MBObserved]) * self.NDot[t] + self.ForgetRate[MBObserved] * self.EWSZS[t].sum(0)

			tmp = self.EWSZS[t] + self.eta[t]
			tmp = (1/self.NDot[t]) * (tmp - tmp.sum(0) * self.Phi[t])
			tmp1= (2/self.NDot[t]) * self.Phi[t]
			tmp = self.Phi[t] + self.epsit[MBObserved] * tmp + np.sqrt(self.epsit[MBObserved] * tmp1) * np.random.randn(self.Phi[t].shape[0],self.Phi[t].shape[1])
			self.Phi[t] = PGBN_sampler.ProjSimplexSpecial(tmp,self.Phi[t],0)
            

	def updateParams(self,totalGradients):
		for i in range(len(self.params)):

			self.m[i] = self.beta1_Weight*self.m[i]+(1-self.beta1_Weight)*totalGradients[i]
			self.v[i] = self.beta2_Weight*self.v[i]+(1-self.beta2_Weight)*(totalGradients[i]**2)
			m_mean = self.m[i]/(1-self.beta1_Weight)
			v_mean = self.v[i]/(1-self.beta2_Weight)
			self.params[i] += self.learning_rate_Weight * m_mean /(np.sqrt(v_mean)+self.epsilon)

	def calculateLB(self,miniBatch,Phi,P):

		for l in range(self.Sampling_Num):
			Theta1_e = np.random.uniform(0,1,[self.Num_dic1,miniBatch.shape[1]])
			Theta2_e = np.random.uniform(0,1,[self.Num_dic2,miniBatch.shape[1]])
			Theta3_e = np.random.uniform(0,1,[self.Num_dic3,miniBatch.shape[1]])

			LB = self.lowerboundfunc(*P,x=miniBatch,Phi1=Phi[0],Phi2=Phi[1],Phi3=Phi[2],
									 Theta1_eps=Theta1_e,Theta2_eps=Theta2_e,Theta3_eps=Theta3_e)

		return LB