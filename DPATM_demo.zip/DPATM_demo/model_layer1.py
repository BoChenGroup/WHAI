# -*- coding: utf-8 -*-
"""
@author : Hao Zhang, Dandan Guo, Bo Chen, and Mingyuan Zhou 
@Email : zhanghao_xidian@163.com      gdd_xidian@126.com    bchen@mail.xidian.edu.cn  mingyuan.zhou@mccombs.utexas.edu

Description:
    The module function realizing one-layer model in WHAI

Citation: 
    WHAI: Weibull Hybrid Autoencoding Inference for Deep Topic Modeling
    Hao Zhang, Bo Chen, Dandan Guo, and Mingyuan Zhou
    ICLR 2018

Contact:
    Hao Zhang
    zhanghao_xidian@163.com
    Xidian University, Xi'an, China
       
    Bo Chen
    bchen@mail.xidian.edu.cn
    Xidian University, Xi'an, China
   
LICENSE
=======================================================================
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
Copyright (c), 2018, Hao Zhang 
zhanghao_xidian@163.com
       
"""



import numpy as np
import theano as th
import theano.tensor as T
import numpy.random as rng
import PGBN_sampler


class model:
    def __init__(self, dimX, Num, Num_dic, batch_size, Sampling_Num, updataparam, method, Prior, eulergamma, Dataname, H,eta,Setting):

        self.dimX = dimX
        self.Num_dic = Num_dic[0]
        self.Num = Num
        self.Sampling_Num = Sampling_Num
        self.Dataname = Dataname

        self.ThetaShape_prior = Prior[0]        
        self.ThetaScale_prior = Prior[1]        

        self.eta = eta         
        self.H = H[0]              


        self.learning_rate_Weight = updataparam[0]
        self.beta1_Weight = updataparam[1]
        self.beta2_Weight = updataparam[2]
        self.epsilon = updataparam[3]
            

        self.batch_size = batch_size
        self.sigmaInit = 0.01
        
        self.Lowerbound = 0
        self.Likelihood = 0
        
        self.eulergamma = eulergamma
        
        self.ForgetRate = np.power((Setting['tao0FR'] + np.linspace(1,Setting['Iterall'],Setting['Iterall'])),-Setting['kappa0FR'])
        epsit = np.power((Setting['tao0'] + np.linspace(1,Setting['Iterall'],Setting['Iterall'])),-Setting['kappa0'])
        self.epsit = Setting['epsi0']*epsit/epsit[0]
        
        self.MBObserved = 0


        
    def initParams(self):
        realmin = 2.2e-308

        Phi = []
        Phi.append(0.2+0.8*np.random.rand(self.dimX,self.Num_dic))
        self.Phi = Phi[0] / np.maximum(realmin,Phi[0].sum(0))  

        
        W1 = np.random.normal(0,self.sigmaInit,[self.H,self.dimX])
        b1 = np.random.normal(0,self.sigmaInit,[self.H,1])

        W3 = np.random.normal(0,self.sigmaInit,[self.Num_dic,self.H])
        b3 = np.random.normal(0,self.sigmaInit,[self.Num_dic,1])   
        
        W2 = np.random.normal(0,self.sigmaInit,[1,self.H])
        b2 = np.random.normal(0,self.sigmaInit,[1,1])
        self.params = [W1,W2,W3,b1,b2,b3]
        

        self.m = [0] * len(self.params)
        self.v = [0] * len(self.params)
        
    def KL_GamWei(self,GamShape,GamScale,WeiShape,WeiScale):
        Out = self.eulergamma * (1-1/WeiShape) + T.log(WeiScale/WeiShape) + 1 + GamShape*T.log(GamScale) - T.gammaln(GamShape) + (GamShape-1)*(T.log(WeiScale)-self.eulergamma/WeiShape) - GamScale*WeiScale*T.gamma(1 + 1/WeiShape)
        
        return Out
        
    def createGradientFunctions(self):
        #Create the Theano variables
        Phi,W1,W2,W3,x,Theta_eps = T.dmatrices("Phi","W1","W2","W3","x","Theta_eps")
        b1,b2,b3 = T.dcols("b1","b2","b3")        
        alpha = T.scalar("alpha")

        h = T.nnet.softplus(T.dot(W1,T.log(1+x))+b1)
        Theta_shape = T.maximum(T.exp(T.dot(W2,h)+b2),1e-8)
        Theta_scale = T.maximum(T.exp(T.dot(W3,h)+b3),1e-8)   
        
        Theta_shape = T.repeat(Theta_shape,self.Num_dic,axis=0)
        Theta_KL = T.sum(self.KL_GamWei(self.ThetaShape_prior, self.ThetaScale_prior, Theta_shape, Theta_scale))           
               
              
        Theta = (Theta_scale * ((-T.log(1-Theta_eps)) ** (1/Theta_shape)) ) 

        Likelihood = T.sum(x*T.log(T.dot(Phi,Theta)) - T.dot(Phi,Theta) - T.gammaln(x+1) )               

       
        gradvariables = [W1,W2,W3,b1,b2,b3]
        
        Loss =  self.Num/self.batch_size*alpha*Theta_KL + self.Num/self.batch_size*Likelihood 
        LB =  Theta_KL + Likelihood 
             
        derivatives = T.grad(Loss,gradvariables)        
              
        derivatives.append(LB)
        derivatives.append(Likelihood)

        self.gradientfunction= th.function(gradvariables+[x,Phi,Theta_eps,alpha], derivatives, on_unused_input='ignore')
        self.likelihoodfunc = th.function(gradvariables+[x,Phi,Theta_eps], Likelihood , on_unused_input='ignore')
        self.thetafunc = th.function(gradvariables+[x,Theta_eps],Theta, on_unused_input='ignore')        

        
    def iterate(self,P,data,epoch):
       	"""Main method, slices data in minibatches and performs an iteration"""
        [dimX,N] = data.shape
        randperm = rng.permutation(N)
        data_tmp = np.array(data[:,randperm],order = 'C')
        batches = np.arange(0,N,self.batch_size)
        alpha = 0.01
        
        if batches[-1] != N:
            batches = np.append(batches,N) 
        MBratio = len(batches)-1

        for MBt in range(MBratio):
            self.MBObserved = (epoch-1)*MBratio + MBt
            
            miniBatch = data_tmp[:,batches[MBt]:batches[MBt+1]]       
            
            P = self.params                                
            totalGradients = self.getGradients(miniBatch,P,epoch,alpha)
            self.updateParams(totalGradients)
            
            Theta = self.calculateTheta(miniBatch,self.params)            
            self.updatePhi(totalGradients,MBratio,self.MBObserved,miniBatch,Theta)
            

       
    def getGradients(self,miniBatch,P,epoch,alpha):
        totalGradients = [0]*len(self.params)  

        for l in range(self.Sampling_Num):
            Theta_e = np.random.uniform(0,1,[self.Num_dic,miniBatch.shape[1]])    


            gradients = self.gradientfunction(*P,x=miniBatch,Phi=self.Phi,Theta_eps=Theta_e,alpha=alpha)
            for i in range(len(self.params)):
                totalGradients[i] += gradients[i]

        self.Lowerbound += gradients[-2]
        self.Likelihood += gradients[-1]
            
        return totalGradients
        
        
    def calculatelikelihood(self,miniBatch,Phi,P):       

        for l in range(self.Sampling_Num):
            Theta_e = np.random.uniform(0,1,[self.Num_dic,miniBatch.shape[1]]) 
            LH = self.likelihoodfunc(*P,x=miniBatch,Phi=Phi,Theta_eps=Theta_e)            
            
        return LH  

    def calculateTheta(self,X,P):       

        for l in range(self.Sampling_Num):
            Theta_e = np.random.uniform(0,1,[self.Num_dic,X.shape[1]]) 
      
            Theta= self.thetafunc(*P,x=X,Theta_eps=Theta_e)         
             
        return Theta   
        
    def updatePhi(self,totalGradients,MBratio,MBObserved,miniBatch,Theta):    
        Xt = miniBatch         
        Xt_to_t1, WSZS = PGBN_sampler.Multrnd_Matrix(Xt.astype('double'),self.Phi,Theta)            
   
        EWSZS =  WSZS
        EWSZS = MBratio * EWSZS 

        if (MBObserved == 0):
            self.NDot = EWSZS.sum(0)
        else:
            self.NDot = (1 - self.ForgetRate[MBObserved]) * self.NDot + self.ForgetRate[MBObserved] * EWSZS.sum(0)
        tmp = EWSZS + self.eta
        tmp = (1/self.NDot) * (tmp - tmp.sum(0) * self.Phi)
        tmp1= (2/self.NDot) * self.Phi

        tmp = self.Phi + self.epsit[MBObserved] * tmp + np.sqrt(self.epsit[MBObserved] * tmp1) * np.random.randn(self.Phi.shape[0],self.Phi.shape[1])
        self.Phi = PGBN_sampler.ProjSimplexSpecial(tmp,self.Phi,0)  
                        
    def updateParams(self,totalGradients):  
        for i in range(len(self.params)):             
                        
            self.m[i] = self.beta1_Weight*self.m[i]+(1-self.beta1_Weight)*totalGradients[i]
            self.v[i] = self.beta2_Weight*self.v[i]+(1-self.beta2_Weight)*(totalGradients[i]**2)
            m_mean = self.m[i]/(1-self.beta1_Weight)
            v_mean = self.v[i]/(1-self.beta2_Weight)                
            self.params[i] += self.learning_rate_Weight * m_mean /(np.sqrt(v_mean)+self.epsilon)
              