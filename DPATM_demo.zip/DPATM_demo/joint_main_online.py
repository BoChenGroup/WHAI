# -*- coding: utf-8 -*-
"""
@author : Hao Zhang, Dandan Guo, Bo Chen, and Mingyuan Zhou 
@Email : zhanghao_xidian@163.com      gdd_xidian@126.com    bchen@mail.xidian.edu.cn  mingyuan.zhou@mccombs.utexas.edu

Description:
    Main code for the ICLR 2018 paper : WHAI: Weibull Hybrid Autoencoding Inference for Deep Topic Modeling

Citation: 
    WHAI: Weibull Hybrid Autoencoding Inference for Deep Topic Modeling
    Hao Zhang, Bo Chen, Dandan Guo, and Mingyuan Zhou
    ICLR 2018

Contact:
    Hao Zhang
    zhanghao_xidian@163.com
    Xidian University, Xi'an, China
       
   Bo Chen
   bchen@mail.xidian.edu.cn
   Xidian University, Xi'an, China
   
LICENSE
=======================================================================
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
Copyright (c), 2018, Hao Zhang 
zhanghao_xidian@163.com
       
"""

import scipy.io as sio
import numpy as np
import time


print ("Loading data")

Dataname = 'MNIST'

if Dataname == 'MNIST':
    data = sio.loadmat('./data/MNIST')
    X_train= np.round(data['X_train']/255)
    X_test= np.round(data['X_test']/255)
    
elif Dataname == '20Newsgroup':
    data = sio.loadmat('./data/20Newsgroup')
    X_train= data['X_train']
    X_test= data['X_test']
    length_test = np.sum(X_test,0)
    





batch_size = 200
[dimX,Num] = X_train.shape
[dimX,Num_test] = X_test.shape

eulergamma = np.float32(0.5772)


T=1
if T==1:
    Num_dic = [64]
    eta = 0.1
elif T==2:
    Num_dic = [64,32]
    eta=[0.1,0.1]
elif T==3:
    Num_dic = [64,32,16]
    eta=[0.1,0.1,0.1]



if T==1:
    import model_layer1
    H = Num_dic
    
    Theta1Shape_prior=np.float32(0.01);Theta1Scale_prior=np.float32(1)  
    Prior = [Theta1Shape_prior,Theta1Scale_prior]
elif T==2:
    import model_layer2

    H = Num_dic

    Theta1Scale_prior=np.float32(1)  
    Theta2Shape_prior=np.float32(0.01);Theta2Scale_prior=np.float32(1) 
    Prior = [Theta1Scale_prior,Theta2Shape_prior,Theta2Scale_prior]  

elif T==3:
    import model_layer3

    H = Num_dic

    Theta1Scale_prior=np.float32(1)  
    Theta2Scale_prior=np.float32(1)  
    Theta3Shape_prior=np.float32(0.01);Theta3Scale_prior=np.float32(1)  
    Prior = [Theta1Scale_prior,Theta2Scale_prior,Theta3Shape_prior,Theta3Scale_prior] 
    

    
Sampling_Num = 1
method = 'ADAM'
    
learning_rate_Weight = 0.0001
beta1_Weight = 0.9
beta2_Weight = 0.99
updataparam = [learning_rate_Weight,beta1_Weight,beta2_Weight,1e-8]      
    
    
Maxiter = 400

Setting = {}
Setting['Iterall'] = Maxiter*(Num/batch_size);  


Setting['tao0FR'] = 0  ;  Setting['kappa0FR'] = 0.9
Setting['tao0'] = 20    ;  Setting['kappa0'] = 0.7
Setting['epsi0'] = 1



if T==1:    
    model = model_layer1.model(dimX,Num,Num_dic,batch_size,Sampling_Num,updataparam,method,Prior,eulergamma,Dataname,H,eta,Setting)
elif T==2:    
    model = model_layer2.model(dimX,Num,Num_dic,batch_size,Sampling_Num,updataparam,method,Prior,eulergamma,Dataname,H,eta,Setting)
elif T==3:    
    model = model_layer3.model(dimX,Num,Num_dic,batch_size,Sampling_Num,updataparam,method,Prior,eulergamma,Dataname,H,eta,Setting)

print ("Creating Theano functions")
model.createGradientFunctions()


print ("Initializing weights and biases")
model.initParams()


Likelihood_train = np.array([])
Likelihood_test = np.array([])
Lowerbound = np.array([])

First_layer = np.array([])
Second_layer = np.array([])
Third_layer = np.array([])
Test_perplexity = np.array([])

for epoch in range(1,Maxiter):
    testperp = 0
    model.Lowerbound = 0
    model.Likelihood = 0
    
    if np.mod(epoch,100)==0:
        model.learning_rate_Weight = model.learning_rate_Weight/2
        
    NetPara_first = model.params
    Phi  = model.Phi

    begin = time.time()
    model.iterate(NetPara_first,X_train,epoch)   
    end = time.time()
   
    Likelihood_train = np.append(Likelihood_train,model.Likelihood/Num)
    Lowerbound = np.append(Lowerbound,model.Lowerbound/Num)
    
    NetPara_first = model.params
    Phi  = model.Phi    
    Likelihood_test = np.append(Likelihood_test,model.calculatelikelihood(X_test,Phi,NetPara_first)/Num_test)

   
    print( "Epoch" + str(epoch) + " Training Likelihood " + str(Likelihood_train[-1]) + " Training LB " +str(Lowerbound[-1]) + " Test Likelihood " + str(Likelihood_test[-1]) + " Time " + str(end-begin))
